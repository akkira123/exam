﻿Public Class club
    Private Sub club_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "ВыставкаСобакDataSet.Клубы". При необходимости она может быть перемещена или удалена.
        Me.КлубыTableAdapter.Fill(Me.ВыставкаСобакDataSet.Клубы)

    End Sub

    Private Sub КлубыDataGridView_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles КлубыDataGridView.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class