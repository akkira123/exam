﻿Public Class ychastnik
    Private Sub ychastnik_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "ВыставкаСобакDataSet.Участники". При необходимости она может быть перемещена или удалена.
        Me.УчастникиTableAdapter.Fill(Me.ВыставкаСобакDataSet.Участники)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class