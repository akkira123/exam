﻿Public Class expert
    Private Sub expert_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "ВыставкаСобакDataSet.Эксперты". При необходимости она может быть перемещена или удалена.
        Me.ЭкспертыTableAdapter.Fill(Me.ВыставкаСобакDataSet.Эксперты)

    End Sub

    Private Sub BindingNavigatorMoveLastItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorMoveLastItem.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()

    End Sub
End Class