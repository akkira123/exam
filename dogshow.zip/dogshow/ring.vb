﻿Public Class ring
    Private Sub РингBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles РингBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.РингBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ВыставкаСобакDataSet)

    End Sub

    Private Sub ring_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "ВыставкаСобакDataSet.Ринг". При необходимости она может быть перемещена или удалена.
        Me.РингTableAdapter.Fill(Me.ВыставкаСобакDataSet.Ринг)

    End Sub

    Private Sub РингBindingNavigator_RefreshItems(sender As Object, e As EventArgs) Handles РингBindingNavigator.RefreshItems

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class